import streamlit as st
import pandas as pd
import joblib
from pathlib import Path
import sys

# Add src to module path
sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))

from data_prep import create_delay_target, basic_feature_engineering
from recommend import recommend_action

st.set_page_config(page_title="Predictive Delivery Optimizer", layout="wide")

st.title("🚚 Predictive Delivery Optimizer")

# Load data
@st.cache_data
def load_data():
    df = pd.read_csv("data/orders.csv", parse_dates=['order_date','dispatch_date','expected_delivery_date','delivery_date'])
    df = create_delay_target(df)
    df = basic_feature_engineering(df)
    return df

df = load_data()

# Load Model
model = joblib.load("models/delay_model.pkl")

# KPI METRICS
col1, col2, col3 = st.columns(3)
col1.metric("Total Orders", len(df))
col2.metric("Delayed (Count)", df['delay_flag'].sum())
col3.metric("Delay Rate (%)", round(df['delay_flag'].mean()*100,2))


# ---------------- TABS ----------------
tab1, tab2, tab3 = st.tabs(["📊 Overview", "🚚 Delay Analytics", "🏷️ High Risk Orders"])

with tab1:
    st.subheader("Data Sample")
    st.write(df.head())
    st.write("Total Orders:", len(df))
    st.write("Delayed Orders:", df['delay_flag'].sum())

with tab2:
    st.subheader("Delay Percentage by Warehouse")
    st.bar_chart(df.groupby('warehouse_name')['delay_flag'].mean())

    st.subheader("Delay by Product Type")
    st.bar_chart(df.groupby('product_type')['delay_flag'].mean())

with tab3:
    st.subheader("Top 15 Highest Risk Orders (Predicted)")
    df['delay_prob'] = model.predict_proba(df[['distance_km','order_weekday','is_express']])[:,1]
    risky = df.sort_values('delay_prob', ascending=False).head(15)
    st.dataframe(risky[['order_id','warehouse_name','distance_km','delay_prob']])


# ---------------- Single Order Prediction ----------------
st.header("🧠 Predict Delay for an Order")

order_id = st.selectbox("Select Order ID", df['order_id'].unique())

row = df[df['order_id'] == order_id].iloc[0]
features = ['distance_km','order_weekday','is_express']
X = pd.DataFrame([row[features]])

prob = model.predict_proba(X)[0,1]
st.metric("Predicted Delay Probability", f"{prob:.2f}")

st.subheader("📌 Recommended Actions")
actions = recommend_action(row, prob)
for a in actions:
    st.write("- ", a)


# ---------------- Batch Upload Predictions ----------------
st.header("📥 Batch Prediction Upload")
file = st.file_uploader("Upload Orders CSV", type=["csv"])

if file:
    batch = pd.read_csv(file)
    batch = basic_feature_engineering(batch)
    batch['delay_prob'] = model.predict_proba(batch[['distance_km','order_weekday','is_express']])[:,1]
    
    st.write(batch.head())
    st.download_button(
        "Download Results",
        batch.to_csv(index=False),
        "predictions.csv",
        mime="text/csv"
    )


# ---------------- Business Impact Section ----------------
st.header("💼 Estimated Business Impact")

delay_rate = df['delay_flag'].mean()
potential_savings = round(delay_rate * 0.15 * 100000, 2)  # simple logic

st.write(f"Estimated Operational Savings: ₹ {potential_savings}")
st.write("Early delay prediction reduces expedited shipping cost & SLA breach penalties.")
