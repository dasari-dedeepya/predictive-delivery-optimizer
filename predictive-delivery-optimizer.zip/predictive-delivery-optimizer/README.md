# 🚚 Predictive Delivery Optimizer

This project predicts delivery delays using historical logistics data and recommends corrective actions to reduce operational risk.

---

## ✅ Features

- Machine learning–based delay prediction
- High-risk order ranking
- Operational delay analytics
- Batch CSV prediction upload
- Business impact estimation
- Actionable recommendations

---

## 🧠 Tech Stack

- Python
- Streamlit
- scikit-learn
- pandas
- joblib

---

## 📂 Folder Structure

