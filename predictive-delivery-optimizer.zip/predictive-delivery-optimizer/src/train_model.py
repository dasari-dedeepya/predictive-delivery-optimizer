import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from data_prep import load_csvs, create_delay_target, basic_feature_engineering

def train():
    orders, *_ = load_csvs("data")
    orders = create_delay_target(orders)
    orders = basic_feature_engineering(orders)

    features = ['distance_km','order_weekday','is_express']
    X = orders[features]
    y = orders['delay_flag']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

    model = RandomForestClassifier()
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    print(classification_report(y_test, preds))

    joblib.dump(model, "models/delay_model.pkl")
    print("✅ Model saved!")

if __name__ == "__main__":
    train()
