def recommend_action(row, prob):
    actions = []
    if prob > 0.7:
        actions.append("Notify customer proactively")
        actions.append("Re-route using faster vehicle")
    if row['distance_km'] > 1000:
        actions.append("Use long-haul transport")
    if row['is_express'] == 1:
        actions.append("Prioritize dispatch")
    if not actions:
        actions.append("Low risk order — no action needed")
    return actions
