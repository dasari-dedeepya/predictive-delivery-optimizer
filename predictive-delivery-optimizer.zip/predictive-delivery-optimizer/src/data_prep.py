import pandas as pd

def load_csvs(data_dir="data"):
    orders = pd.read_csv(f"{data_dir}/orders.csv", parse_dates=['order_date','dispatch_date','expected_delivery_date','delivery_date'])
    warehouse_inventory = pd.read_csv(f"{data_dir}/warehouse_inventory.csv")
    vehicles = pd.read_csv(f"{data_dir}/vehicles.csv")
    routes = pd.read_csv(f"{data_dir}/routes.csv")
    weather = pd.read_csv(f"{data_dir}/weather.csv", parse_dates=['date'])
    traffic = pd.read_csv(f"{data_dir}/traffic.csv", parse_dates=['timestamp'])
    customers = pd.read_csv(f"{data_dir}/customers.csv")

    return orders, warehouse_inventory, vehicles, routes, weather, traffic, customers

def create_delay_target(df):
    df['delay_days'] = (df['delivery_date'] - df['expected_delivery_date']).dt.days
    df['delay_flag'] = (df['delay_days'] > 0).astype(int)
    return df

def basic_feature_engineering(df):
    df['order_weekday'] = df['order_date'].dt.weekday
    df['distance_km'] = pd.to_numeric(df['distance_km'], errors='coerce').fillna(0)
    df['is_express'] = (df['customer_priority'] == "Express").astype(int)
    return df
